git add .
git commit -am "$1"
git push -u origin refactor
eb deploy
